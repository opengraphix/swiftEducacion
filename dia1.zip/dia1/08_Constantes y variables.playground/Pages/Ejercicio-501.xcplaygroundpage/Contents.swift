/*:
 ## Ejercicio: 501
 
 Es posible que conozcas el popular juego de dardos llamado 501. Los jugadores comienzan con un puntaje de 501 y deben llegar a cero. Estas son las reglas:
 
 - Cada jugador juega una “ronda” en la que tira tres dardos a un tablero.
 - Con cada tiro, se pueden obtener entre 1 y 20 puntos, que pueden duplicarse o triplicarse según dónde caiga el dardo en el tablero.
 - También es posible obtener 25 por los blancos externos y 50 por los blancos internos.
 
 Regla: Al término de tres rondas, la persona que esté más cerca del cero sin llegar a estar por debajo del cero es la ganadora.
 
 - callout(Ejercicio): Imagina que eres experto en este juego. Quieres engañar a las personas para que crean que no juegas bien, para luego recuperarte y vencerlos de una sola vez al final. Representa el progreso de tu juego usando variables.\
 \
 Comienza con una variable configurada en `501` para contener tu puntaje general.\
 Crea otra variable configurada en `0` para contener el puntaje de cada ronda.\
 Para cada tiro, actualiza el valor del puntaje de la ronda sumando los puntos del tiro.\
 Al término de cada ronda, calcula tu puntaje general actual restándole el puntaje de la ronda. Asigna el nuevo valor a tu puntaje general y vuelve a configurar el puntaje de la ronda en cero.\
 \
 ¿Qué tan lentamente puedes “mejorar” tu desempeño en el juego sin levantar sospechas? \
 \
 Después de cada ronda, imprime con `print` algunas instrucciones que podrían realizar tus oponentes. Si puedes, usa el valor de tu puntaje actual en sus instrucciones.
*/



/*:
 _Copyright © 2016 Apple Inc. Todos los derechos reservados._\
 _Para obtener información acerca de la licencia de este ejemplo, consulta el archivo LICENSE.txt_
*/
//: [Anterior](@previous)  |  Página 13 de 13
