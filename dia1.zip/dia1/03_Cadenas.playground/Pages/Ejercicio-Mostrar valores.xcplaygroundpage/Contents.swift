/*:
 ## Ejercicio: Mostrar valores
 
 Tal vez recuerdes un ejercicio de un área de juego anterior en el que debías calcular el espacio restante en un iPhone. Tenías la siguiente información:
 
 - La capacidad de un iPhone se mide en gigabytes (GB). El iPhone en cuestión tiene 8 GB de almacenamiento.
 - Un gigabyte equivale a aproximadamente 1000 megabytes (MB).
 - El teléfono ya tiene 3 GB de capacidad ocupada.
 - Un minuto de video ocupa 150 MB de espacio.
 
 - callout(Ejercicio): Crea una cadena que le indique al usuario cuántos minutos de video puede almacenar en el teléfono. Primero, debes realizar los pasos de cálculo; luego, usa la interpolación de cadenas para mostrar la respuesta, que debería ser similar a esta:
 
 `Puedes almacenar XXX minutos más de video.`
 
 _Sugerencia_: Realiza todos los cálculos en megabytes.
 */






/*:
 _Copyright © 2016 Apple Inc. Todos los derechos reservados._\
 _Para obtener información acerca de la licencia de este ejemplo, consulta el archivo LICENSE.txt_.
 */
//:
//: [Anterior](@previous)  |  Página 16 de 16
