/*:
 ## Ejercicio: Años bisiestos
 
 Para decidir si un año es bisiesto, primero es necesario tomar algunas otras decisiones:
 
 - ¿El año es divisible por 4?
    - De ser así, ¿es divisible por 100?
        - De no ser así, es un año bisiesto.
        - De ser así, ¿es divisible por 400?
            - De no ser así, **no** es un año bisiesto.
            - De ser así, es un año bisiesto.
 
 Puedes tomar estas decisiones dentro de una función.
 
 La función `number(_:, isDivisibleBy:)` (número[_:, es divisible por:]) fue diseñada en esta área de juego para facilitar la realización de este ejercicio. Más abajo, encontrarás una función incompleta para decidir si un año determinado es bisiesto:
*/
func isLeapYear(_ year: Int) -> Bool {
    if number(year, isDivisibleBy: 4) {
        // Completa este código...
        return true
    } else {
        return false
    }
}
// Debería ser verdadero.
isLeapYear(2000)
// Debería ser falso.
isLeapYear(1900)
// Debería ser verdadero.
isLeapYear(2012)
// Debería ser falso.
isLeapYear(2017)
//: - callout(Ejercicio): Completa la función que está arriba de modo que las reglas se respeten y los ejemplos tengan las respuestas correctas.
/*:
 _Copyright © 2016 Apple Inc. Todos los derechos reservados._\
 _Para obtener información acerca de la licencia de este ejemplo, consulta el archivo LICENSE.txt_
 
[Anterior](@previous)  |  Página 13 de 13
*/
