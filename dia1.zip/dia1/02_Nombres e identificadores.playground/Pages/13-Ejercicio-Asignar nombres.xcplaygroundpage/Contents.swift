/*:
 ## Ejercicio: Nombres útiles
 
 Heredaste un código de otro programador que nunca tuvo la oportunidad de realizar el curso _Desarrollo de apps con Swift_. Lo único que encontraste fue una nota que tenía escrito lo siguiente:
 
 > (Nota): 
 > **Guía de carga de camiones**
 >
 > Peso de cajones de naranjas: 100 lb (45 kg)
 >
 > Peso de cajones de sandías: 200 lb (90 kg)
 >
 > Hay que cargar la parte izquierda y luego la parte derecha del camión para equilibrar el peso. ¿Qué cantidad va de cada lado? Las sandías siempre van juntas.
*/
let co = 14
let cw = 3

let ow = 100
let ww = 200

let to = co * ow
let tw = cw * ww

let ttl = to + tw

let es = ttl / 2

let lhso = es / ow
let rhso = co - lhso


//: - experiment:(Experimento): Vuelve a escribir el código de modo que funcione sin la necesidad de agregar una nota. Usa nombres y comentarios significativos.






/*:
 _Copyright © 2016 Apple Inc. Todos los derechos reservados._\
 _Para obtener información acerca de la licencia de este ejemplo, consulta el archivo LICENSE.txt_.
*/
//:[Anterior](@previous)  |  Página 14 de 14
