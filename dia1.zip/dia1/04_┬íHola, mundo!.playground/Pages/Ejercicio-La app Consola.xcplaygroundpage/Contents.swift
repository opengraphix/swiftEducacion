/*:
 ## Ejercicio: La app Consola
 
 ¿Qué clases de mensajes se pueden enviar a una consola?
 
 Si quieres echar un vistazo a algunos mensajes que otros programadores decidieron imprimir en tu Mac, abre el Finder y ve a Aplicaciones > Utilidades > Consola. Verás una secuencia de texto que parecerá, en su mayoría, sin sentido alguno. Estos son mensajes privados entre los desarrolladores que, por lo general, usan expresiones internas que solo entienden las personas que conocen cada app.
 
 Desplázate por algunos mensajes y luego cierra la app Consola.
*/
/*:
 _Copyright © 2016 Apple Inc. Todos los derechos reservados._\
 _Para obtener información acerca de la licencia de este ejemplo, consulta el archivo LICENSE.txt_.
 
[Anterior](@previous)  |  Página 11 de 11
*/
