/*:
 ## Meme personal
 
 Copia las funciones que creaste en el ejercicio anterior en esta página si lo deseas o vuelve a escribirlas para practicar. También puedes crear un conjunto nuevo.
 
 Dentro de una de las funciones, introduce cambios para que todo el texto cambie de significado o sea más gracioso. Podrías cambiar uno de los nombres por el tuyo o el de un amigo, cambiar una palabra para generar una rima o simplemente probar lo que se te ocurra.
*/




















/*:
 _Copyright © 2016 Apple Inc. Todos los derechos reservados._\
 _Para obtener información acerca de la licencia de este ejemplo, consulta el archivo LICENSE.txt_
*/
//: [Anterior](@previous)  |  Página 12 de 12
