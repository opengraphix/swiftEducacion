/*:
 ## Tipos importantes
 
 En la vida real, usar el tipo de objeto correcto es muy importante.
 
 Si estás jugando al tenis, es importante usar una pelota en vez de cualquier otra clase de objeto, como un huevo.
 
 Por otra parte, tener una docena de pelotas de tenis no es muy útil si estás tratando de hacer un omelet.
 
 Cada tipo de objeto tiene diferentes propiedades y comportamientos. Una pelota de tenis está llena de aire y rebota si la arrojas. Un huevo está lleno de clara y yema, y se rompe si lo arrojas.
  
 En programación, los tipos funcionan de manera muy similar.
 
 Por ejemplo, ya usaste un tipo denominado “cadena” para trabajar con caracteres y texto. Las cadenas tienen propiedades y comportamientos adaptados para ese propósito.
 
 Avanza para aprender más sobre los tipos en Swift.
 
Página 1 de 13  |  [Siguiente: Tipos](@next)
*/
