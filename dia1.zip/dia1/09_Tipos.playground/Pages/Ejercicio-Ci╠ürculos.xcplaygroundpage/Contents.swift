/*:
 ## Ejercicio: Círculos
 
 La circunferencia de un círculo (la longitud del contorno) puede calcularse si se multiplica el diámetro del círculo (la distancia transversal) por **ᴨ** (pi).
 
 Valor aproximado de pi:
*/
let pi = 3.14159265359
//: - callout(Ejercicio): Escribe un programa para calcular la circunferencia de un círculo con un diámetro de 2. Crea una constante que contenga el valor del diámetro. ¿De qué tipo debe ser la constante? 

/*:
 _Copyright © 2016 Apple Inc. Todos los derechos reservados._\
 _Para obtener información acerca de la licencia de este ejemplo, consulta el archivo LICENSE.txt_

[Anterior](@previous)  |  Página 13 de 13
*/
