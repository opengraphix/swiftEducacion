/*:
 ## Ejercicio: Sin etiqueta de argumento
 
 Algunos nombres de funciones son muy descriptivos y, por lo tanto, no es necesario incluir una etiqueta para su argumento. Para escribir una función que se pueda llamar únicamente con un argumento, utiliza `_` donde normalmente especificarías la etiqueta de argumento.
 
 La siguiente función tiene una etiqueta de argumento innecesaria cuando la llamas.
*/
func holler(phrase: String) -> String {
    return "⚡️\(phrase)!!⚡️"
}

holler(phrase: "Gracias, me encanta.")
holler(phrase: "No era necesario.")
/*:
 - callout(Ejercicio): Actualiza la definición de la función para que pueda llamarse de la siguiente manera:\
 `holler("¡Qué sorpresa!")`

 _Copyright © 2016 Apple Inc. Todos los derechos reservados._\
 _Para obtener información acerca de la licencia de este ejemplo, consulta el archivo LICENSE.txt_
 
[Anterior](@previous)  |  Página 17 de 17
*/
