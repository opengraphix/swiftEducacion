//: ## Resumen
//: En esta área de juego, pudiste realizar un recorrido breve por las áreas de juego y la barra lateral de resultados. Además, aprendiste lo que debes hacer a fin de estar listo para programar:
//: - Hacer cálculos matemáticos.
//: - Usar comentarios.
//: - Corregir errores cuando no obtienes los resultados esperados.
//:
//: ¡Felicitaciones! 
//:
/*:
 _Copyright © 2016 Apple Inc. Todos los derechos reservados._\
 _Para obtener información acerca de la licencia de este ejemplo, consulta el archivo LICENSE.txt_
*/
//:[Anterior](@previous)  |  Página 7 de 7
