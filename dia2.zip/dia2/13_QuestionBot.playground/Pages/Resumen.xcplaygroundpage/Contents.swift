/*:
 ## Resumen
 Te esforzaste mucho para darle un cerebro a QuestionBot y comprobaste lo útil que pueden ser las áreas de juego para trabajar en funciones individuales sin distracciones.
 
 En la última parte de la lección, debes tomar la función nueva que creaste en la página anterior e incluirla en la app.
 
 Las instrucciones para hacerlo están en la Guía, en la lección “QuestionBot”.*/
/*:
 _Copyright © 2016 Apple Inc. Todos los derechos reservados._\
 _Para obtener información acerca de la licencia de este ejemplo, consulta el archivo LICENSE.txt_
*/
//:[Anterior](@previous)  |  Página 7 de 7
