﻿/*:
 ## Ejercicio: Mostrar mensajes

 De alguna manera, tienes una lista enorme de mensajes sobre una serie de personajes: Oruga, Lirón, Gato de Cheshire y otros. La lista está incluida en la constante `aliceMessages` (mensajes de Alicia) que aparece debajo.
 
 Intenta imprimir el arreglo `aliceMessages` para ver la lista completa, pero ten cuidado porque es larga y es posible que tu área de juego se ejecute con lentitud.
*/
import Foundation

aliceMessages


/*:
 La oruga te pidió que revises los mensajes y transmitas todos los que contienen su nombre. En lugar de leer cada mensaje por tu cuenta, decides escribir más código como ayuda.
 
 - callout(Ejercicio): Crea un bucle `for...in` para procesar el conjunto `aliceMessages`.\
En el cuerpo del bucle, usa el método `contains` (contiene) para comprobar si los mensajes tienen la cadena "Oruga".\
Si el mensaje hace referencia a la oruga, imprímelo en la consola.
 

 - note:(Nota): 
El método `contains` es parte del marco `Foundation` sobre el cual leíste en el área de juego “Tipos”. Si intentas usarlo, se generará un error con el mensaje: “Value of type 'String' has no member 'contains'” (El valor del tipo “String” no tiene miembro “contains”). Sigue las instrucciones del área de juego para importar el marco al proyecto.
*/
// Escribe el bucle `for...in` aquí:


/*:
 _Copyright © 2016 Apple Inc. Todos los derechos reservados._\
 _Para obtener información acerca de la licencia de este ejemplo, consulta el archivo LICENSE.txt_
*/
//: [Anterior](@previous)  |  Página 17 de 17
