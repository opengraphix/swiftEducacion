/*:
 ## Ejercicio: Instrucciones “switch”
 
 Esta enum representa los objetivos que el jugador puede lograr en un juego:
*/
enum Target {
    case red, green, blue, gold
}
//: Esta función devuelve un puntaje según un objetivo particular:
func score(target: Target) -> Int {
    return 0
}
//: - callout(Ejercicio): Cambia la función `score(target:)` para usar una instrucción “switch” y que devuelva el puntaje correcto de cada objetivo. En las instrucciones que aparecen a continuación, se indican los valores a los que debes apuntar:
score(target: .red)    // Este debe ser 10
score(target: .green)  // Este debe ser 15
score(target: .blue)   // Este debe ser 25
score(target: .gold)   // Este debe ser 50

/*:
 _Copyright © 2016 Apple Inc. Todos los derechos reservados._\
 _Para obtener información acerca de la licencia de este ejemplo, consulta el archivo LICENSE.txt_.
 
[Anterior](@previous)  |  Página 21 de 21
*/
