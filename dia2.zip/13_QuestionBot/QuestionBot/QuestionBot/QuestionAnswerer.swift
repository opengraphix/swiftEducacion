struct MyQuestionAnswerer {
    func responseTo(question: String) -> String {
        // TODO: Write a response 
        var mensaje = ""
        let question = question.lowercased()
        
        if question.hasPrefix("hello"){
            mensaje = "Why, hello there"
        } else if question == "where are the cookies?"{
            mensaje = "In the cookie jar!"
        } else if question.hasPrefix("where") {
            mensaje = "To the North!"
        } else {
            let numero = question.characters.count % 3
            print("\(question.characters.count) \(numero)")
            if  numero == 0 {
                mensaje = "It depennds"
            } else if numero == 1{
                mensaje = "I do not know"
            } else {
                mensaje = "not sure"
            }
        }
        return mensaje

    }
}
