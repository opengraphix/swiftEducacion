/*:
  ## Ejercicio: Tu propia estructura
 Cuando trabajaste con el área de juego “Tipos”, pudiste pensar algunos ejemplos de tipos de la vida real y los tipos asociados de los que podrían depender. Un tipo `TrainingShoe` (calzado deportivo), por ejemplo, puede tener una propiedad `size` (talle), que es una `Int`, una propiedad `brandName` (marca) que es una `String` y una propiedad `releaseDate` (fecha de lanzamiento) que es una `Date` (fecha).

 - callout(Ejercicio): 
 Piensa en otro objeto de la vida real y sus propiedades. Imagina acciones o comportamientos que podría realizar el objeto. Escribe todo, primero, en un español simple, en un comentario:
*/
 // Agrega la descripción del tipo en español aquí. Asegúrate de agregar // antes de cada línea de tu comentario de descripción.
 //
 //
 //

/*:
 - callout(Ejercicio): 
 Usando la sintaxis de `struct` de esta lección, crea un tipo para tu objeto de la vida real con las propiedades y los métodos que imaginaste. Recuerda marcar cada propiedad con `let` o `var` según si quieres poder cambiarla o no. Si no recuerdas bien cómo implementar el cuerpo de uno de los métodos, describe en un comentario qué debe hacer el método.\
 *Pista: Si generaste propiedades con tipos personalizados, puedes crear tipos comodines que tengan implementaciones vacías. (Consulta el código de TrainingShoe al principio de esta página como ejemplo). El tipo comodín que aparece a continuación te asegurará poder ejecutar el área de juego sin errores.*
*/
// Agrega tu propia struct aquí:






/*:
 - callout(Ejercicio): 
 Usa la struct que creaste para hacer una instancia nueva de tu tipo.

*/


/*:
 - note:(Nota): Este es un ejemplo de un tipo comodín utilizado para hacer un TrainingShoe:
*/
// Tipo comodín
struct Shoelaces {

}

struct TrainingShoe {
    let size: Int
    var isTied: Bool
    var laces: Shoelaces

    func squeak() {
        // Hacer un ruido fuerte como el chirrido de la suela de goma sobre el piso del gimnasio
    }

    func warnAboutLaces() {
        // Si los cordones están desatados, imprimir un recordatorio para atarlos
    }
}

// Crea una instancia del tipo comodín
let newLaces = Shoelaces()

// Usa la instancia del tipo comodín para crear una instancia de tu tipo nuevo
let newShoe = TrainingShoe(size: 39, isTied: true, laces: newLaces)





/*:
 _Copyright © 2016 Apple Inc. Todos los derechos reservados._\
 _Para obtener información acerca de la licencia de este ejemplo, consulta el archivo LICENSE.txt_
 
 [Anterior](@previous)  |  Página 9 de 9
*/
