/*:
 ## Ejercicio: Identidad
 
 ¿Qué significa que un valor de instancia tenga su propia identidad?

 - callout(Ejercicio): 
 Crea una variable para `myPlans` (mis planes) que se inicialice en una cadena que describa los planes que tienes para la noche.\
Crea una segunda variable para `friendPlans` (planes de amigo), pero que se inicialice en `myPlans`. (Tu amigo tiene menos iniciativa que tú para planificar).\
Debajo de la declaración de `friendPlans`, actualiza `myPlans` utilizando el operador de adición `+` para agregar una actividad más.\
Comprueba los valores de `myPlans` y `friendPlans`. ¿Son iguales o diferentes?
*/
// Crea tus variables aquí:



// Actualiza `myPlans` aquí:




/*:
 - callout(Ejercicio): 
 Crea una función `addDance` (agregar baile) que tome una cadena, agregue una frase sobre baile (como `"¡y luego bailamos!"` o `"pero sin bailar"`, según lo que te guste) y devuelva la cadena nueva.\
Llama a la función `addDance` en `myPlans` y asigna el resultado a `friendPlans`.
*/
// Define y llama a tu función aquí:




/*:
 - callout(Ejercicio): 
 ¿Cómo esperas que cambie `friendPlans`? ¿Cómo esperas que cambie `myPlans`?\
 Imprime ambas instancias para averiguarlo.
*/
// Imprime aquí y comprueba si se cumplió lo que esperabas:




/*:
 _Copyright © 2016 Apple Inc. Todos los derechos reservados._\
 _Para obtener información acerca de la licencia de este ejemplo, consulta el archivo LICENSE.txt_
 
[Anterior](@previous)  |  Página 17 de 17
*/
